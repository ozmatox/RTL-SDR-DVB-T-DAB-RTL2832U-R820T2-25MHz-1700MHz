<add key="DAP" value="SDRSharp.DAP.DAPPlugin,SDRSharp.DAP" />
