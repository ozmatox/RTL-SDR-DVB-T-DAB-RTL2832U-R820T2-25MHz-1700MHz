Install:
Copy all dlls to the SDRSharp folder.
Add line to FrontEnds.xml 
<add key="RTL-SDR (R820T)" value="SDRSharp.R820T.RtlSdrIO,SDRSharp.R820T" />


Whats new:
Built-in decimation.
3 gain settings.
Based on Oliver's driver for 13-1864 MHz.
"On fly" decimation and samplerate change.

Autors:
SDRSharp.RTLSDR.dll - Youssef Touil and other contributors, http://sdrsharp.com/
hacked Beliakov Vasili, http://rtl-sdr.ru/

librtlsdr.dll - http://sdrr820tmanualgainsettings.sourceforge.net/

