The Windows build is using
https://github.com/libusbx/libusbx 33ba1231a1b07425eaa83935f84b2e4b7f904f35
and
http://sources.redhat.com/pthreads-win32/ cvs
See the corresponding COPYING* files for the license text.

You might need to grab the runtime from
http://www.microsoft.com/en-us/download/details.aspx?id=8328
or
http://www.microsoft.com/en-us/download/details.aspx?id=13523